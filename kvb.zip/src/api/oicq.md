# oicq v2 API {#oicq-api}

> 详情请参考 [`oicq` 文档](https://oicqjs.github.io/oicq) 。

## Bot API

`bot` 的实质是 oicq 的 Client 实例，参考 `oicq` 文档的 [`Client`](https://oicqjs.github.io/oicq/classes/Client.html) 类。

## segment

用于构造复杂的 QQ 消息（图片、QQ 表情、语言、视频等），参考 `oicq` 文档的 [`segment`](https://oicqjs.github.io/oicq/modules.html#segment) API。

> 待完善，请先参考 [oicq 文档](https://oicqjs.github.io/oicq)。
