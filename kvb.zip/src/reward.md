---
aside: false
editLink: false
lastUpdated: false
outline: false
---

# 支持本项目 {#support}

## 🔈 声明 {#claim}

1. `KiviBot` 是**完全免费且开放源代码**的软件, 仅供学习和娱乐使用。
2. 完全出于兴趣开发, **不会通过任何方式强制索取费用**, 或对使用者提出物质条件。
3. 精力有限, 同时维护框架、文档以及诸多官方插件实属不易, 感谢理解与支持。

你可以给本项目的 [GitHub](https://github.com/KiviBotLab/KiviBot) 仓库点个 star 进行支持。~~可以的话再给你喜欢的插件仓库点点 star。~~

## 💰 赞赏 {#reward}

当然, 你也可以通过赞赏的方式来支持, 促进项目更好的发展。

> 赞赏采取**自愿**原则, 收到的赞赏将用于提高开发者积极性和开发环境。

<div style="display: flex; flex-wrap: wrap;">
  <div style="display: flex; align-items: center; flex-direction: column;">
    <img src="https://smms.deno.dev/2022/11/16/X2kFMdaxvSc1V5P.jpg" alt="wxpay" width="160px" style="margin: 24px;"/>
  </div>
  <div style="display: flex; align-items: center; flex-direction: column;">
    <img src="https://smms.deno.dev/2022/11/16/vZ4xkCopKRmIFVX.jpg" alt="alipay" width="160px"  style="margin:24px;"/>
  </div>
</div>
