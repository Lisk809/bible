export const blockPlugins = []
export const blockAuthors = ['penana']
